package com.wcd.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wcd.dao.ICourseDao;

import model.Course;
@Service
public class CourseServiceImpl implements ICourseService {

private ICourseDao coursedao;
@Autowired
	public void setCoursedao(ICourseDao coursedao) {
	this.coursedao = coursedao;
}

	@Override
	@Transactional
	public void addCourseDet(Course n) {
		System.out.println("going to view");
this.coursedao.addCourseDet(n);
	}

	@Override
	@Transactional
	public void updateCourseDet(Course p) {
		this.coursedao.updateCourseDet(p);
		
	}

	@Override
	@Transactional
	public List<Course> listCourseDetail() {
	
		return this.coursedao.listCourseDetail();
	}

	@Override
	@Transactional
	public Course getCourseById(int id) {

		return this.coursedao.getCourseById(id);
	}

	@Override
	@Transactional
	public void removeCourse(int id) {
		this.coursedao.removeCourse(id);
		
	}
	@Override
	@Transactional
	public List<Course> listCourseByCAO(String ngoName, String courseName) {
		
		return this.coursedao.listCourseByCAO(ngoName,courseName);
	}

}
