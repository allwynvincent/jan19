package com.wcd.service;

import model.Ngo;

public interface IAdminService {
	public Ngo returnNgo(Ngo n);
}
