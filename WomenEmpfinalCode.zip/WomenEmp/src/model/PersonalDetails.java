package model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;
@Component
@Entity
public class PersonalDetails implements Serializable{
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int personalId;
private String firstName;
private String lastName;
//private int age;
private String aadhaarCard;
private String Pancard;
private String bloodGroup;
private Date dob;
public int getPersonalId() {
	return personalId;
}
public void setPersonalId(int personalId) {
	this.personalId = personalId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getAadhaarCard() {
	return aadhaarCard;
}
public void setAadhaarCard(String aadhaarCard) {
	this.aadhaarCard = aadhaarCard;
}
public String getPancard() {
	return Pancard;
}
public void setPancard(String pancard) {
	Pancard = pancard;
}
public String getBloodGroup() {
	return bloodGroup;
}
public void setBloodGroup(String bloodGroup) {
	this.bloodGroup = bloodGroup;
}
public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}
@Override
public String toString() {
	return "PersonalDetails [personalId=" + personalId + ", firstName=" + firstName + ", lastName=" + lastName
			+ ", aadhaarCard=" + aadhaarCard + ", Pancard=" + Pancard + ", bloodGroup=" + bloodGroup + ", dob=" + dob
			+ "]";
}
public PersonalDetails(int personalId, String firstName, String lastName, String aadhaarCard, String pancard,
		String bloodGroup, Date dob) {
	super();
	this.personalId = personalId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.aadhaarCard = aadhaarCard;
	Pancard = pancard;
	this.bloodGroup = bloodGroup;
	this.dob = dob;
}
public PersonalDetails() {
	super();
}

}
