package model;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;
@Component
@Entity
public class TrainingCourse implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int trainingId;
private String ngoName;
private String courseName;
public int getTrainingId() {
	return trainingId;
}
public void setTrainingId(int trainingId) {
	this.trainingId = trainingId;
}
public String getNgoName() {
	return ngoName;
}
public void setNgoName(String ngoName) {
	this.ngoName = ngoName;
}
public String getCourseName() {
	return courseName;
}
public void setCourseName(String courseName) {
	this.courseName = courseName;
}
@Override
public String toString() {
	return "TrainingCourse [trainingId=" + trainingId + ", ngoName=" + ngoName + ", courseName=" + courseName + "]";
}
public TrainingCourse(int trainingId, String ngoName, String courseName) {
	super();
	this.trainingId = trainingId;
	this.ngoName = ngoName;
	this.courseName = courseName;
}
public TrainingCourse() {
	super();
}


}
